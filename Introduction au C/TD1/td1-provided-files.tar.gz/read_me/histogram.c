/*
**  file: histogram.c
**  authors: Assistants
*/

#include <stdio.h>

#define HISTO_SIZE 3

int histo(char sentence[])
{
    int index = 0;
    int histo[HISTO_SIZE] = { 0 };

    while (sentence[index] != '\0')
    {
        int letter = sentence[index];

        if (letter >= 'a' && letter <= 'z') // check if letter is lowercase
            histo[0] = histo[0] + 1;
        else if (letter >= 'A' && letter <= 'Z')
            histo[1] += 1;
        else
            histo[2]++;

        index++;
    }

    printf("There are %d lowercase letters.\n", histo[0]);
    printf("There are %d uppercase letters.\n", histo[1]);
    printf("%d characters left.\n", histo[2]);

    return index;
}

int main(int argc, char *argv[])
{
    if (argc != 2)
    {
        puts("[USAGE]: ./histo <sentence>");
        return 1;
    }

    int len = histo(argv[1]);

    printf("%s length is %d.\n", argv[1], len);

    return 0;
}
