#ifndef PAGE_BEGIN_H
#define PAGE_BEGIN_H

#include <stddef.h>

void *page_begin(void *ptr, size_t page_size);

#endif /* !PAGE_BEGIN_H */
