#ifndef BEWARE_OVERFLOW_H
#define BEWARE_OVERFLOW_H

#include <stddef.h>

void *beware_overflow(void *ptr, size_t nmemb, size_t size);

#endif /* BEWARE_OVERFLOW_H */
