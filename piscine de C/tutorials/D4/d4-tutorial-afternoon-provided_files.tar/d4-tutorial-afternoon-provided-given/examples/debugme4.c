#include <stdio.h>

int recursive_function(int i)
{
    int res = 0;

    if (!i)
    {
        return i;
    }
    else
    {
        for (int j = 0; j <= i; ++j)
        {
            res += j + j * j / i;
        }
    }

    return res + recursive_function(i - 1);
}

int main(void)
{
    int val = 6942;

    printf("recursive_function(%d) = %d\n", val, recursive_function(val));

    return 0;
}
