#include <stdio.h>
#include <string.h>

void never_called(size_t a)
{
    printf("Never Call Me Daddy ! (a = %zu)\n)", a);
}

int main(void)
{
    char string[] = "Adrien";
    size_t a = 2;

    if (a == strlen(string))
        never_called(a);

    return 0;
}
