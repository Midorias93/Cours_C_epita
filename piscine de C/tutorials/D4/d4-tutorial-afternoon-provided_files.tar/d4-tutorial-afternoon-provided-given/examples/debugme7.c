#include <stdio.h>

#define ARRAY_SIZE 6

enum shirt_size
{
    XS,
    S,
    M,
    L,
    XL
};

struct ACU
{
    char *name;
    char *role;
    enum shirt_size size;
    unsigned int age;
};

int main(void)
{
    struct ACU ACU2024[ARRAY_SIZE] = {
        { .name = "Adrien", .role = "Piscine", .size = M, .age = 69 },
        { .name = "Antoine", .role = "Piscine", .size = XL, .age = 2 },
        { .name = "Ethan", .role = "Piscine", .size = M, .age = 42 },
        { .name = "Nigel", .role = "Piscine/HTTPD", .size = M, .age = 20 },
        { .name = "Pauline", .role = "Piscine/SQL", .size = M, .age = 22 },
        { .name = "Thuraya", .role = "Piscine/SQL", .size = S, .age = 21 }
    };

    for (size_t i = 0; i < ARRAY_SIZE; ++i)
        printf("name: %s\n", ACU2024[i].name);

    return 0;
}
