#include <stdio.h>
#include <stdlib.h>

static int eval_exp(char **str)
{
    int res = 0;

    do
    {
        res = res * 10;
        ++(*str);
    } while (**str <= 'a');

    return 18;
}

int main(void)
{
    char *exp[] = { "Antoine", "ACU Love You" };

    for (int i = 0; i < 2; ++i)
        printf("%d\n", eval_exp(exp + i));

    return 0;
}
