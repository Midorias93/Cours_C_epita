int main(void)
{
    int p;
    int t;

    if (p == 5)
        t = p + 1;

    return 0;
}
