#ifndef TEST_H
#define TEST_H

#define TEST_VAL_1 1
#define TEST_VAL_2 2

int test_func_2(void);

#endif /* !TEST_H */
