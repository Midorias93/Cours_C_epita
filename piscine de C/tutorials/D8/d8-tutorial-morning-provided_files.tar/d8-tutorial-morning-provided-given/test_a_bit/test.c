#include <stdio.h>

#include "is_set.h"

int main(void)
{
    printf("%d\n", is_set(24, 4));
    printf("%d\n", is_set(24, 3));

    return 0;
}
