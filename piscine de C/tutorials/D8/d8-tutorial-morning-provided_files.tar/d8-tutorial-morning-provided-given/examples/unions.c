#include <stdint.h>
#include <stdio.h>

union integer
{
    int8_t smallest;
    int16_t small;
    int32_t big;
    int64_t biggest;
};

union int_or_string
{
    int int_t;
    char *str_t;
};

int main(void)
{
    union int_or_string value;

    value.int_t = 12;
    printf("The value is now: %i\n", value.int_t);

    value.str_t = "acu";
    printf("The value is now: %s\n", value.str_t);

    return 0;
}
