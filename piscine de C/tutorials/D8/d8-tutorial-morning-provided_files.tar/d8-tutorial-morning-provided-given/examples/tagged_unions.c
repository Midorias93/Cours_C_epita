#include <stdio.h>

union int_or_string
{
    int int_t;
    char *str_t;
};

enum age_or_name
{
    AGE,
    NAME
};

struct student
{
    enum age_or_name tag;
    union int_or_string data;
};

int main(void)
{
    struct student ing1;
    ing1.tag = NAME;
    ing1.data.str_t = "Thibault";

    if (ing1.tag == NAME)
        printf("Hello ! My name is %s\n", ing1.data.str_t);
    else
        printf("Hello ! I am %d years old\n", ing1.data.int_t);

    return 0;
}
