#include <stdio.h>

int main(void)
{
    int day = 12;
    char month[] = "September";
    printf("Today is the %dth of %s %d.\n", day, month, 2000);
    
    return 0;
}
