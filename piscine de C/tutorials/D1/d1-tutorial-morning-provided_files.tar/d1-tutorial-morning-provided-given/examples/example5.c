#include <stdio.h>

int main(void)
{
    char a = 'a';
    printf("%c\n", a); // a
    printf("%d\n", a); // 97
    printf("%f\n", a); // 0.000000
    
    return 0;
}
