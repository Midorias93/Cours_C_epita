#ifndef ARRAY_VICE_MAX_H
#define ARRAY_VICE_MAX_H

#include <stddef.h>

int array_vice_max(const int vec[], size_t size);

#endif /* !ARRAY_VICE_MAX_H */
