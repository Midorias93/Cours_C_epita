#!/bin/sh

# Here we will use command substitution to fetch our result, as it spawns a
# subshell 'res' will only be alive inside the command substitution

concat() {
    res=""

    for arg; do
        res="${ res}${ arg}"
    done

    echo "$res"
}

echo "concat res: $(concat 1 2 3 4 5)"
