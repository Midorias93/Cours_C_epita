typedef void (*const free_function)(void*);

struct list
{
    void *value;
    free_function elt_free;
    struct list *next;
};

void list_free(struct list *head)
{
    if (!head)
        return;

    struct list *next = head->next;

    if (head->value && head->elt_free)
        head->elt_free(head->value);

    free(head);
    list_free(next);
}
