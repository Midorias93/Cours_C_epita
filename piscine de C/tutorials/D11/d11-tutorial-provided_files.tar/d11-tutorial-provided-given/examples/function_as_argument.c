#include <stdlib.h>

struct student
{
    int uid;
    char login[8];
    int promo;
};

int compare_student(const void *a, const void *b)
{
    const struct student *e1 = a;
    const struct student *e2 = b;
    return (e1->uid - e2->uid);
}

int main(void)
{
    struct student *students;
    int nb_students = 0;

    // Add students // ...

    // Sort by student's uid
    qsort(students, nb_students, sizeof (struct student), compare_student);
}
