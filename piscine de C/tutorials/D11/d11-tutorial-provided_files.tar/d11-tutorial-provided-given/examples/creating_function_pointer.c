typedef int (*bin_op)(int, int);

int sum(int a, int b)
{
    return a + b;
}

int main(void)
{
    int (*op)(int, int); // Verbose declaration
    op = sum; // op is a variable

    bin_op op2 = sum; // Using the alias

    // op2 is a variable
    int res = op(2, 3); // Call the function pointed by op
    res = (*op)(2, 3); // The same call, without syntactic sugar

    int res2 = op2(2, 3); // Call the function pointed by op2
                          //
    return res == res2; // res and res2 are equal
}
