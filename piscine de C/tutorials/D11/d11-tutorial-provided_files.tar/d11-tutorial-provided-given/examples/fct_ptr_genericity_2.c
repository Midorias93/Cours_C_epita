typedef void (*const free_function)(void*);

void list_free(struct list *head, free_function elt_free)
{
    if (!head)
        return;

    struct list *next = head->next;

    if (head->value && elt_free)
        elt_free(head->value);

    free(head);
    list_free(next, elt_free);
}
