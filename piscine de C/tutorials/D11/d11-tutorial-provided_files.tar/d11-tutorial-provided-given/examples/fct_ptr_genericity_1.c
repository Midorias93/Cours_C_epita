struct list
{
    void *value;
    struct list *next;
};

void list_free(struct list *head)
{
    if (!head)
        return;

    struct list *next = head->next;

    if (head->value)
        free(head->value); // free the current element

    free(head);
    list_free(next); // free the rest of the list
}
