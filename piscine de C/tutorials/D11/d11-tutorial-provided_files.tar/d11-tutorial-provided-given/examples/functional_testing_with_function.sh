#!/bin/sh

REF_OUT=".echo.out"
TEST_OUT=".my_echo.out"

testcase() {
    echo $@ > "$REF_OUT"
    ./my_echo $@ > "$TEST_OUT"

    diff "$REF_OUT" "$TEST_OUT"
}

testcase a b c
testcase 42 sh
testcase -n a b c
testcase test -n a b c
