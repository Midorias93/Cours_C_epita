#!/bin/sh

# Here we simply call our function without a subshell, thus total res its
# value after the function call.

concat() {
    res=""
    for arg; do
        res="${ res}${ arg}"
    done
}

concat 1 2 3 4 5
echo "concat res: $res"
