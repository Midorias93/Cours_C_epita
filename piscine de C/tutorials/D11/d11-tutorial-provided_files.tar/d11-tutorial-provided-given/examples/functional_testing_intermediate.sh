#!/bin/sh

REF_OUT=".echo.out"
TEST_OUT=".my_echo.out"

echo a b c > "$REF_OUT"
./my_echo a b c > "$TEST_OUT"

diff "$REF_OUT" "$TEST_OUT"

echo 42 sh > "$REF_OUT"
./my_echo 42 sh > "$TEST_OUT"

diff "$REF_OUT" "$TEST_OUT"

echo -n a b c > "$REF_OUT"
./my_echo -n a b c > "$TEST_OUT"

diff "$REF_OUT" "$TEST_OUT"

echo test -n a b c > "$REF_OUT"
./my_echo test -n a b c > "$TEST_OUT"

diff "$REF_OUT" "$TEST_OUT"
