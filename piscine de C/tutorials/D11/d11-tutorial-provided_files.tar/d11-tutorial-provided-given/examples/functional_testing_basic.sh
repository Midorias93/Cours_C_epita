#!/bin/sh
#
REF_OUT=".echo.out"
TEST_OUT=".my_echo.out"

echo a b c > "$REF_OUT"
./my_echo a b c > "$TEST_OUT"

diff "$REF_OUT" "$TEST_OUT"
