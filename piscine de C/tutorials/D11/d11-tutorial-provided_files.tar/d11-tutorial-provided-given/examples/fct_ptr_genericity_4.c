typedef void (*const free_function)(void*);

struct element
{
    void *data;
    free_function free;
};

void element_free(struct element *elt)
{
    if (!elt)
        return;

    if (elt->data && elt->free)
        elt->free(elt->data);

    free(elt);
}

struct list
{
    struct element *value;
    struct list *next;
};

void list_free(struct list *head)
{
    if (!head)
        return;

    struct list *next = head->next;

    element_free(head->value);
    free(head);
    list_free(next);
}
